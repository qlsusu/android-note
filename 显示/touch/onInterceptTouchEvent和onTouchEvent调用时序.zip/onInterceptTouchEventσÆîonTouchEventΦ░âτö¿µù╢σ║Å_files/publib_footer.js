﻿document.write("<link rel='stylesheet' type='text/css' href='http://csdnimg.cn/pubfooter/css/pub_footerstyle.css' />");
document.write("<div class='pub_footerall'>");
document.write("<dl>");
document.write("<dt></dt>");
document.write(" <dd><a href='http://www.csdn.net/company/about.html' target='_blank'>公司简介</a>|<a href='http://www.csdn.net/company/recruit.html' target='_blank'>招贤纳士</a>|<a href='http://www.csdn.net/company/marketing.html' target='_blank'>广告服务</a>|<a href='http://www.csdn.net/company/account.html' target='_blank'>银行汇款帐号</a>|<a href='http://www.csdn.net/company/contact.html' target='_blank'>联系方式</a>|<a href='http://www.csdn.net/company/statement.html' target='_blank'>版权声明</a>|<a href='http://www.csdn.net/company/layer.html' target='_blank'>法律顾问</a>|<a href='mailto:webmaster@csdn.net'>问题报告</a></dd>");
document.write("<dd>北京创新乐知广告有限公司 版权所有,&nbsp;京&nbsp;ICP&nbsp;证&nbsp;070598&nbsp;号</dd>");
document.write("<dd>世纪乐知(北京)网络技术有限公司 提供技术支持</dd>");
document.write("<dd>江苏乐知网络技术有限公司 提供商务支持</dd>");
document.write("<dd><img src='http://csdnimg.cn/www/images/pic_email.gif' alt='' title='' /> Email:webmaster@csdn.net</dd>");
document.write("<dd>Copyright &copy; 1999-2010, CSDN.NET, All Rights Reserved</dd>");
document.write("<dd><a href='http://www.hd315.gov.cn/beian/view.asp?bianhao=010202001032100010' target='_blank'><img src='http://www.csdn.net/ui/images/gongshang_logos.gif' alt='GongshangLogo' alt='' title='' /></a></dd>");
document.write("</dl>");
document.write("</div>");
            
            
            
            
            
            
            
            
            
            
            
            
               
            
            
         
            
            
            
            
          
      
          
            
          
