package com.ql.testMyDrawer;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ListView;

import com.ql.view.MySlidingDrawer;

public class Test extends Activity {
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		MySlidingDrawer drawer = (MySlidingDrawer) findViewById(R.id.drawer);
		drawer.setContentListenerRunnable(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub

				GridView imageView = (GridView) findViewById(R.id.image);
				GridView videoView = (GridView) findViewById(R.id.video);
				ListView musicView = (ListView) findViewById(R.id.music);
				ListView etcView = (ListView) findViewById(R.id.etc);

				etcView.setAdapter(new ArrayAdapter<String>(Test.this,
						android.R.layout.simple_list_item_1, new String[] {
								"1", "2" }));
				etcView.setOnItemClickListener(new OnItemClickListener() {

					@Override
					public void onItemClick(AdapterView<?> parent, View view,
							int position, long id) {
						// TODO Auto-generated method stub
						System.out.println("position is:" + position);
					}
				});

			}
		});
	}
}