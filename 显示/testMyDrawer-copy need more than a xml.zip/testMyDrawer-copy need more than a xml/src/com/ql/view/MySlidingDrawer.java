package com.ql.view;

import java.lang.reflect.Field;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.ql.mover.MyDrawerMoverSub;
import com.ql.mover.MyMover;
import com.ql.testMyDrawer.R;

public class MySlidingDrawer extends ViewGroup {

	private Runnable childListenerRunnable;
	private int drawerLayoutId;

	public MySlidingDrawer(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		// TODO Auto-generated constructor stub
	}

	public MySlidingDrawer(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		String drawerLayoutName;
		TypedArray a = context.obtainStyledAttributes(attrs,
				R.styleable.mySlidingDrawerattr);
		drawerLayoutName = a
				.getString(R.styleable.mySlidingDrawerattr_drawerLayout);

		try {
			Field f = R.layout.class.getField(drawerLayoutName);
			drawerLayoutId = (Integer) f.get(drawerLayoutName);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		a.recycle();
	}

	public MySlidingDrawer(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		// TODO Auto-generated method stub
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);

		int spec = MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED);
		handler.measure(spec, spec);
		setMeasuredDimension(handler.getMeasuredWidth(),
				handler.getMeasuredHeight());
	}

	@Override
	protected void onLayout(boolean changed, int l, int t, int r, int b) {
		// TODO Auto-generated method stub
		// because we don't want to draw any child, so it is empty here
	}

	private View handler;

	@Override
	protected void onFinishInflate() {
		// TODO Auto-generated method stub
		super.onFinishInflate();
		removeAllViews();
		LayoutInflater inflater = (LayoutInflater) getContext()
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

		handler = inflater.inflate(drawerLayoutId, null).findViewById(
				R.id.handler);

		((ViewGroup) handler.getParent()).removeView(handler);
		addView(handler);
	}

	@Override
	protected void dispatchDraw(Canvas canvas) {
		// TODO Auto-generated method stub
		// comparing with other callback method, it will be called at last, so
		// we enableMove here
		enableMove();
	}

	private void enableMove() {
		View v = this;
		View root = null;
		// because View.getRootView doesn't return FrameLayout, so we use this
		// strategy to find root
		while (true) {
			v = (View) v.getParent();
			if (v.getId() == R.id.root) {
				root = v;
				break;
			}
		}

		ViewGroup father = (ViewGroup) getParent();

		int index = father.indexOfChild(this);
		father.removeView(this);
		((ViewGroup) handler.getParent()).removeView(handler);
		father.addView(handler, index);

		MyMover mover = new MyDrawerMoverSub(getContext(), new Handler(),
				drawerLayoutId, childListenerRunnable);
		mover.enableMove(handler, (ViewGroup) root);
	}

	public void setContentListenerRunnable(Runnable childListenerRunnable) {
		this.childListenerRunnable = childListenerRunnable;
	}
}
