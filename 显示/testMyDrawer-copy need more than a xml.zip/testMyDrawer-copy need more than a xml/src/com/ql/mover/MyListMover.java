package com.ql.mover;

import android.content.Context;
import android.os.Handler;
import android.view.View;
import android.widget.AbsoluteLayout;
import android.widget.AdapterView;

/**
 * 
 * @author qlsusu 任意移动AdapterView的孩子
 * 
 */
public class MyListMover extends MyMover {

	private AdapterView<?> aView;
	// 长按的是哪一个item
	private int lastMovedItemPosition;

	public MyListMover(Context context, Handler handler) {
		super(context, handler);
		// TODO Auto-generated constructor stub
	}

	public void onEnableMove() {
		if (!(src instanceof AdapterView<?>)) {
			return;
		}

		aView = (AdapterView<?>) src;
		aView.setOnTouchListener(onTouchListener);
		aView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {

			@Override
			public boolean onItemLongClick(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				// TODO Auto-generated method stub
				lastMovedItemPosition = arg2;
				src = arg1;
				startMoveLife();

				return true;
			}
		});
		src = null;
	}

	@Override
	protected void onRecoverSrc() {
		src.setVisibility(View.VISIBLE);
	}

	@Override
	protected View onConstructCopy() {
		View copy = aView.getAdapter().getView(lastMovedItemPosition, null,
				null);
		return copy;
	}

	@Override
	public void onStopMove() {
		// TODO Auto-generated method stub
		aView.setOnTouchListener(null);
		aView.setOnLongClickListener(null);
		lastMovedItemPosition = -1;
	}

	@Override
	protected void onInitCopyPosition() {
		// TODO Auto-generated method stub
		int[] location1 = new int[2];
		src.getLocationOnScreen(location1);
		
		int[] location2 = new int[2];
		aLayout.getLocationOnScreen(location2);
		
		copy.setLayoutParams(new AbsoluteLayout.LayoutParams(src.getWidth(),
				src.getHeight(), location1[0], location1[1] - location2[1]));
	}

	public int getLastMovedItemPosion() {
		return lastMovedItemPosition;
	}

}
