package com.ql.mover;

import com.ql.testMyDrawer.R;

import android.content.Context;
import android.os.Handler;
import android.view.View;
import android.widget.TabHost;

public class MyDrawerMoverSub extends MyDrawerMover {

	public MyDrawerMoverSub(Context context, Handler handler,
			int drawerLayoutId, Runnable contentListenerRunnable) {
		super(context, handler, drawerLayoutId, contentListenerRunnable);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected View onConstructCopy() {
		// TODO Auto-generated method stub
		View view = super.onConstructCopy();
		TabHost tabHost = (TabHost) view.findViewById(R.id.tabhost);
		tabHost.setup();
		tabHost.addTab(tabHost
				.newTabSpec("Image")
				.setIndicator("Image",
						context.getResources().getDrawable(R.drawable.icon))
				.setContent(R.id.image));
		tabHost.addTab(tabHost
				.newTabSpec("Video")
				.setIndicator("Video",
						context.getResources().getDrawable(R.drawable.icon))
				.setContent(R.id.video));
		tabHost.addTab(tabHost
				.newTabSpec("Music")
				.setIndicator("Music",
						context.getResources().getDrawable(R.drawable.icon))
				.setContent(R.id.music));
		tabHost.addTab(tabHost
				.newTabSpec("etc")
				.setIndicator("etc.",
						context.getResources().getDrawable(R.drawable.icon))
				.setContent(R.id.etc));
		return view;
	}

}
