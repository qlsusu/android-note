package com.ql.mover;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.AbsoluteLayout;

//后续步骤：取消单例
//添加startmove和destroy方法

public abstract class MyMover {

	protected Context context;

	// layout.xml中的根元素
	protected ViewGroup root;

	// 要移动的src的在layout.xml中的father
	protected ViewGroup srcFather;

	// 要移动的src
	protected View src;

	// src是否开启了移动生命
	protected boolean isInMoveLife = false;

	// src的拷贝
	protected View copy;

	// 添加到root中的AbsoluteLayout，copy被放入该layout。更新copy.layoutparams以移动
	protected AbsoluteLayout aLayout;

	// x,y,width,height。
	// copy被移动到该区域内时，将完成响应
	private int[] targetDimension;

	protected Handler handler;

	public final static int SRC_IN_TARGET_DIMENSION = 100;
	public final static int SRC_NOT_IN_TARGET_DIMENSION = 101;

	public MyMover(Context context, Handler handler) {
		this.context = context;
		this.handler = handler;
	}

	public void enableMove(View src, ViewGroup root) {
		this.src = src;
		this.root = root;

		constructAbsoluteLayout();
		onEnableMove();
	}

	public void stopMove() {
		root.removeView(aLayout);
		onStopMove();
	}

	protected void constructAbsoluteLayout() {
		aLayout = new AbsoluteLayout(context);
		aLayout.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,
				LayoutParams.FILL_PARENT));
		root.addView(aLayout);
	}

	public void setDimension(int[] dimension) {
		this.targetDimension = dimension;
	}

	protected void checkInDimension(int x, int y) {
		if (targetDimension == null) {
			return;
		}
		if (x > targetDimension[0]
				&& x < targetDimension[0] + targetDimension[2]
				&& y > targetDimension[1]
				&& y < targetDimension[1] + targetDimension[3]) {
			Message msg = handler.obtainMessage();
			msg.what = SRC_IN_TARGET_DIMENSION;
			handler.sendMessage(msg);
		} else {
			Message msg = handler.obtainMessage();
			msg.what = SRC_NOT_IN_TARGET_DIMENSION;
			handler.sendMessage(msg);
		}
	}

	protected static abstract class MyOnTouchListener implements
			OnTouchListener {
		private int xLast;
		private int yLast;
		private int x;
		private int y;
		protected MyMover mover;

		protected boolean isXMove = true;
		protected boolean isYMove = true;

		public MyOnTouchListener(MyMover mover) {
			super();
			// TODO Auto-generated constructor stub
			this.mover = mover;
		}

		@Override
		public boolean onTouch(View v, MotionEvent event) {
			// TODO Auto-generated method stub
			switch (event.getAction()) {
			case MotionEvent.ACTION_DOWN:
				xLast = (int) event.getRawX();
				yLast = (int) event.getRawY();
				onTouchDown(event);
				break;
			case MotionEvent.ACTION_UP:
				if (mover.isInMoveLife) {
					mover.isInMoveLife = false;
					onTouchUp(event);
				}
				break;
			case MotionEvent.ACTION_MOVE:
				if (mover.isInMoveLife) {
					x = (int) event.getRawX();
					y = (int) event.getRawY();

					AbsoluteLayout.LayoutParams lp = (android.widget.AbsoluteLayout.LayoutParams) mover.copy
							.getLayoutParams();
					if (isXMove) {
						lp.x += x - xLast;
					}
					if (isYMove) {
						lp.y += y - yLast;
					}
					xLast = x;
					yLast = y;
					mover.copy.setLayoutParams(lp);
				}
				break;
			default:
				break;
			}
			return false;
		}

		protected abstract void onTouchDown(MotionEvent event);

		protected abstract void onTouchUp(MotionEvent event);
	}

	// 一个默认的实现
	protected MyOnTouchListener onTouchListener = new MyOnTouchListener(this) {

		@Override
		protected void onTouchDown(MotionEvent event) {
			// TODO Auto-generated method stub

		}

		@Override
		protected void onTouchUp(MotionEvent event) {
			// TODO Auto-generated method stub
			mover.aLayout.removeAllViews();
			if (mover.src != null) {
				mover.onRecoverSrc();
			}
			mover.checkInDimension((int) event.getRawX(), (int) event.getRawY());
		}

	};

	protected void startMoveLife() {
		isInMoveLife = true;
		initCopy();
	}

	protected void initCopy() {
		aLayout.removeAllViews();
		copy = onConstructCopy();
		aLayout.addView(copy);
		onInitCopyPosition();
	}

	protected void setOnTouchListener(MyOnTouchListener onTouchListener) {
		this.onTouchListener = onTouchListener;
	}

	protected abstract void onEnableMove();

	public abstract void onStopMove();

	// do some recoving work to ensure src can move again
	protected abstract void onRecoverSrc();

	protected abstract View onConstructCopy();

	protected abstract void onInitCopyPosition();

}
