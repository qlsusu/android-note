package com.ql.mover;

import com.ql.testMyDrawer.R;

import android.content.Context;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsoluteLayout;

public class MyDrawerMover extends MyMover {

	private ViewGroup srcInitfather;
	private int srcInitIndex = -1;

	private boolean isFlyUpToBottom = true;

	private int drawerLayoutId = -1;

	private Runnable contentListenerRunnable;

	private View lastCopy;

	public MyDrawerMover(Context context, Handler handler, int drawerLayoutId,
			Runnable contentListenerRunnable) {
		super(context, handler);
		this.drawerLayoutId = drawerLayoutId;
		this.contentListenerRunnable = contentListenerRunnable;
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void onEnableMove() {
		// TODO Auto-generated method stub
		if (srcInitIndex == -1) {
			srcInitfather = (ViewGroup) src.getParent();
			srcInitIndex = srcInitfather.indexOfChild(src);
		}

		MyOnTouchListener listener = new MyOnTouchListener(this) {
			private final static int MOVE_STEP = 60;

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				// TODO Auto-generated method stub
				super.onTouch(v, event);
				// src don't have onclicklistener and sth else, so we want src
				// to take full charge of the moving thing
				return true;
			}

			@Override
			protected void onTouchDown(MotionEvent event) {
				// TODO Auto-generated method stub
				// we use first touch src, then start moving life
				startMoveLife();
			}

			@Override
			protected void onTouchUp(MotionEvent event) {
				// TODO Auto-generated method stub
				final AbsoluteLayout.LayoutParams lp = (android.widget.AbsoluteLayout.LayoutParams) mover.copy
						.getLayoutParams();

				// we may want to make an animation to automatically finish the
				// left part.
				// you mustn't use a "while and a contion to quit" here, because
				// drawing will be called on main thread, and so does onTouchUp,
				// and both methods will be assigned in main thread's queue,
				// which means after one method finish, then the other can be
				// popped up to execute.
				// so we use "post and post" strategy here
				handler.post(new Runnable() {
					@Override
					public void run() {
						// TODO Auto-generated method stub
						try {
							Thread.sleep(10);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

						int flag = isFlyUpToBottom ? 1 : -1;

						lp.y += flag * MOVE_STEP;
						mover.copy.setLayoutParams(lp);

						// we may need to stop the animation and do some other
						// work
						boolean condition = isFlyUpToBottom ? lp.y >= 0
								: lp.y <= -580;
						if (condition) {
							lp.y = isFlyUpToBottom ? 0 : -580;

							mover.copy.setLayoutParams(lp);

							if (!isFlyUpToBottom) {
								// if the bottom-to-up-animation stops, we need
								// to recover to make src movable again
								mover.onRecoverSrc();
							} else {
								((MyDrawerMover) mover).isFlyUpToBottom = false;
								mover.enableMove(
										copy.findViewById(R.id.handler), root);
								lastCopy = copy;
								contentListenerRunnable.run();
							}
						} else {
							handler.post(this);
						}
					}
				});
			}
		};
		listener.isXMove = false;
		setOnTouchListener(listener);
		src.setOnTouchListener(onTouchListener);
	}

	@Override
	public void onStopMove() {
		// TODO Auto-generated method stub

	}

	@Override
	protected View onConstructCopy() {
		// TODO Auto-generated method stub
		View view = LayoutInflater.from(context).inflate(drawerLayoutId, null);
		return view;
	}

	@Override
	protected void onInitCopyPosition() {
		// TODO Auto-generated method stub
		int y1 = aLayout.getHeight() - src.getHeight();

		int[] location1 = new int[2];
		int[] location2 = new int[2];
		src.getLocationOnScreen(location1);
		aLayout.getLocationOnScreen(location2);
		int y2 = location1[1] - location2[1];

		copy.setLayoutParams(new AbsoluteLayout.LayoutParams(root.getWidth(),
				root.getHeight(), 0, -y1 + y2));

		View view = lastCopy == null ? src : lastCopy;
		view.setVisibility(View.INVISIBLE);
		lastCopy = null;
	}

	@Override
	protected void onRecoverSrc() {
		// TODO Auto-generated method stub
		// at the end, there are to AbsoluteLayout for up-to-bottom and
		// bottom-to-up situations.
		// and by now, both layouts have made no sense to exist
		root.removeViewAt(root.getChildCount() - 1);
		root.removeViewAt(root.getChildCount() - 1);

		// src will be set to the oldest one
		src = srcInitfather.getChildAt(srcInitIndex);
		src.setVisibility(View.VISIBLE);
		enableMove(src, root);
		// and we will be up-to-bottom
		isFlyUpToBottom = true;
	}
}
