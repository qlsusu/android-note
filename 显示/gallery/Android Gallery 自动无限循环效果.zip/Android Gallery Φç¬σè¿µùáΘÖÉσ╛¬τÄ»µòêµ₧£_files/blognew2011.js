var BLOG_AD = {
	"scroll": {
		'ad': 1,
		'rtt': 1,
		'adnum': 2,
		'ads': {
			'0': {
				'startdate': '2013-04-03 9:00:00',
				'enddate': '2013-04-04 9:30:00',
				'warp': 1,
				'ads': {
					'0': {
						"type": "pic",
						"pos": "scroll",
                                                       "width": 140,
						"height": 150,
						"click": "http://sina.allyes.com/main/adfclick?db=sina&bid=538203,604483,609753&cid=0,0,0&sid=612805&advid=9746&camid=93639&show=ignore&url=http://wwwins.1to1crm.com.cn/web_service/counter/webmax_ad.aspx?NikonAD:201304NikonLDCPDSLRsina:sina003",
						"status": {
							"adstart": "",
							"adend": "",
							"adclose": ""
						},
						"ref": "http://d3.sina.com.cn/201304/02/483298_140-150_20k.jpg",
						"content": ''
					},
					'1': {
						"type": "pic",
						"pos": "scroll",
                                                       "width": 25,
						"height": 150,
						"click": "http://sina.allyes.com/main/adfclick?db=sina&bid=538203,604483,609753&cid=0,0,0&sid=612805&advid=9746&camid=93639&show=ignore&url=http://wwwins.1to1crm.com.cn/web_service/counter/webmax_ad.aspx?NikonAD:201304NikonLDCPDSLRsina:sina003",
						"status": {
							"adstart": "",
							"adend": "",
							"adclose": ""
						},
						"ref": "http://d5.sina.com.cn/201304/02/483206_25150.JPG",
						"content": ''
					}
				}
			},
			'1': {
				'startdate': '2013-04-02 9:00:00',
				'enddate': '2013-04-03 9:30:00',
				'warp': 1,
				'ads': {
					'0': {
						"type": "pic",
						"pos": "scroll",
logurl: 'http://1086.adsina.allyes.com/main/adfshow?user=AFP6_for_SINA|2012_add|2012_blog_tjbw_sxan&db=sina&border=0&local=yes&js=ie',
						"width": 140,
						"height": 150,
						"click": "http://sina.allyes.com/main/adfclick?db=sina&bid=537732,604001,609272&cid=0,0,0&sid=612311&advid=9746&camid=93531&show=ignore&url=http://wwwins.1to1crm.com.cn/web_service/counter/webmax_ad.aspx?NikonAD:201304NikonLDCPpromosina:sina001",
						"status": {
							"adstart": "",
							"adend": "",
							"adclose": ""
						},
						"ref": "http://d1.sina.com.cn/201304/01/483076_140-150_20k.jpg",
						"content": ''
					},
					'1': {
						"type": "pic",
						"pos": "scroll",
logurl: 'http://1086.adsina.allyes.com/main/adfshow?user=AFP6_for_SINA|2012_add|2012_blog_tjbw_sxan&db=sina&border=0&local=yes&js=ie',
						"width": 25,
						"height": 150,
						"click": "http://sina.allyes.com/main/adfclick?db=sina&bid=537732,604001,609272&cid=0,0,0&sid=612311&advid=9746&camid=93531&show=ignore&url=http://wwwins.1to1crm.com.cn/web_service/counter/webmax_ad.aspx?NikonAD:201304NikonLDCPpromosina:sina001",
						"status": {
							"adstart": "",
							"adend": "",
							"adclose": ""
						},
						"ref": "http://d5.sina.com.cn/201304/02/483206_25150.JPG",
						"content": ''
					}
				}
			}
		}
	},
	"comment": {
		'ad': 1,
		'adnum': 3,
		'ads': {
			'0': {
				"type": "txt",
				"pos": "comment",
				"link": '[��Ѷ]<a href="http://bf.sina.com.cn/newbf/zt/ysqm.html"  target="_blank">������������ǩ��</a>',
				"status": {
					"adstart": "",
					"adend": "",
					"adclose": ""
				}
			},
			'1': {
				"type": "txt",
				"pos": "comment",
				"link": '[��Ѷ]<a href="http://sina.allyes.com/main/adfclick?db=sina&bid=277830,334360,339653&cid=0,0,0&sid=334533&advid=7567&camid=52451&show=ignore&url=http://all.vic.sina.com.cn/2011citicgongyi/index.php"  target="_blank">����ǩ�������룬�����ɽ�</a>',
				"status": {
					"adstart": "",
					"adend": "",
					"adclose": ""
				}
			},
			'2': {
				"type": "txt",
				"pos": "comment",
				"link": '[��Ѷ]<a href="http://sina.allyes.com/main/adfclick?db=sina&bid=204720,299859,305135&cid=0,0,0&sid=298939&advid=358&camid=37389&show=ignore&url=http://blog.sina.com.cn/s/blog_705463570100phtd.html?tj=1"  target="_blank">��߲��������·���</a>',
				"status": {
					"adstart": "",
					"adend": "",
					"adclose": ""
				}
			}
		}
	},
	"video": {
		'ad': 1,
		'adnum': 2,
		'rtt': 1,
		'ads': {
			'0': {
				"type": "swf",
				"pos": "video",
                                    "startdate": "2013-3-28 9:00:00",
				"enddate": "2013-3-29 9:30:00",
				"width": 260,
				"height": 190,
				"click": "",
				"status": {
					"adstart": "",
					"adend": "",
					"adclose": ""
				},
				"ref": "http://d2.sina.com.cn/201302/28/478606.swf", 
<!--D3FC92BD6E8F--><!--$$ yuxia/2013-03-28 ~  2013-03-28/B $-->		
         "content": ''
			},
			'1': {
				"type": "swf",
				"pos": "video",
                                    "startdate": "2013-3-25 9:00:00",
				"enddate": "2013-3-26 9:30:00",
				"width": 260,
				"height": 190,
				"click": "",
				"status": {
					"adstart": "",
					"adend": "",
					"adclose": ""
				},
				"ref": "http://d5.sina.com.cn/201303/22/481808.swf",
<!--6325A42DFAEA--><!--$$ yuxia/2013-3-25 ~ 2013-3-25/B $-->
				"content": ''
			}
		}
	},
	"leftsx": {
		'ad': 1,
		'adnum': 2,
		'rtt': 1,
		'ads': {
			'0': {
				"type": "swf",
				"pos": "leftsx",
				'startdate': '2013-4-2 9:00',
				'enddate': '2013-4-3 9:30',
				"width": 210,
				"height": 200,
				"click": "",
				"status": {
					"adstart": "",
					"adend": "",
					"adclose": ""
				},
				"ref": "http://d3.sina.com.cn/201303/22/481815.swf",<!--C449C816D5F3--><!--$$ yuxia/2013-4-2 ~ 2013-4-2/B $-->
				"ref2": "",
				"content": "",
				"isusewb": "false",
				"addata": {
					clickCode: "http://sina.allyes.com/main/adfclick?db=sina&bid=247819,404560,409873&cid=0,0,0&sid=407235&advid=358&camid=46514&show=ignore",
					appkey: "",
					ralateUid: "",
					title: "",
					pic: "",
					url: ""
				},
				'txtarr': [{
					"href": "",
					"content": ""
				}, {
					"href": "",
					"content": ""
				}, {
					"href": "",
					"content": ""
				}, {
					"href": "",
					"content": ""
				}, {
					"href": "",
					"content": ""
				}, {
					"href": "",
					"content": ""
				}]
			},
			'1': {
				"type": "pic",
				"pos": "leftsx",
				'startdate': '2012-09-07 9:00',
				'enddate': '2012-09-11 9:30',
				"width": 200,
				"height": 200,
				"click": "http://sina.allyes.com/main/adfclick?db=sina&bid=204720,507536,512811&cid=0,0,0&sid=512442&advid=358&camid=37389&show=ignore&url=http://blog.sina.com.cn/lm/blog_7years.html?tj=1",
				"status": {
					"adstart": "",
					"adend": "",
					"adclose": ""
				},
				"ref": "http://d1.sina.com.cn/201209/10/453730_200200.gif",
				"ref2": "",
				"content": "",
				"isusewb": "true",
				"addata": {
					clickCode: "http://sina.allyes.com/main/adfclick?db=sina&bid=247819,404560,409873&cid=0,0,0&sid=407235&advid=358&camid=46514&show=ignore",
					appkey: "",
					ralateUid: "",
					title: "",
					pic: "",
					url: ""
				},
				'txtarr': [{
					"href": "",
					"content": ""
				}, {
					"href": "",
					"content": ""
				}, {
					"href": "",
					"content": ""
				}, {
					"href": "",
					"content": ""
				}, {
					"href": "",
					"content": ""
				}, {
					"href": "",
					"content": ""
				}]
			}
		}
	},
	"topbanner": {
		'ad': 1,
		'adnum': 2,
		'rtt': 1,
		'ads': {
			'0': {
				"type": "swf",
				"pos": "topbanner",
				"width": 950,
				"height": 90,
				'startdate': '2013-3-23 09:00:00',
				'enddate': '2013-3-25 09:00:00',
				"click": "",
				"status": {
					"adstart": "",
					"adend": "",
					"adclose": ""
				},
				"ref": "http://d3.sina.com.cn/201303/22/481752.swf",
				"content": ''
			},
			'1': {
				"type": "pic",
				"pos": "topbanner",
				"width": 950,
				"height": 90,
				'startdate': '2012-12-24 09:00:00',
				'enddate': '2012-12-25 08:59:59',
				"click": "http://sina.allyes.com/main/adfclick?db=sina&bid=498476,563417,568689&cid=0,0,0&sid=570669&advid=9318&camid=88523&show=ignore&url=http://edu.sina.com.cn/2012shengdian/",
				"status": {
					"adstart": "",
					"adend": "",
					"adclose": ""
				},
				"ref": "http://d4.sina.com.cn/201212/19/470417.jpg",
				"content": ''
			}
		}
	},
	"jumpin": {
		'ad': 0,
		'adnum': 1,
		'ads': {
			'0': {
				"type": "swf",
				"pos": "jumpin",
				"width": 240,
				"height": 60,
				'startdate': '2011-4-23',
				'enddate': '2011-4-29',
				"click": "http://www.sina.com.cn/",
				"status": {
					"adstart": "",
					"adend": "",
					"adclose": ""
				},
				"ref": "",
				"content": ''
			}
		}
	},
"PDPS000000041399": {  // 300 * 250 ��������ҳ,���л�01
        'ad': 1,
        'adnum': 1,
        'rtt': 1,
        'ads': {
            '0': {
                "type": "swf",// �������swf��flash����, iframe��Ƕ��htmlҳ���棬���ַ���Ϊ������ʽ���
                "pos": "PDPS000000041399",
                "width": 300,
                "height": 250,
                'startdate': '2012-11-27 00:00:01',
                'enddate': '2012-11-27 23:59:59',
                "click": "",
                "status": {
                    "adstart": "",
                    "adend": "",
                    "adclose": ""
                },
                "ref": "http://d2.sina.com.cn/201211/22/465185_300-250-auto.swf",
                "content": ''
            }
        }
    },
    "PDPS000000041400": {  // 300 * 500 ��������ҳ,���л�00
        'ad': 1,
        'adnum': 1,
        'rtt': 1,
        'ads': {
            '0': {
                "type": "swf",// �������swf��flash����, iframe��Ƕ��htmlҳ���棬���ַ���Ϊ������ʽ���
                "pos": "PDPS000000041400",
                "width": 300,
                "height": 500,
                'startdate': '2012-11-27 00:00:01',
                'enddate': '2012-11-27 23:59:59',
                "click": "",
                "status": {
                    "adstart": "",
                    "adend": "",
                    "adclose": ""
                },
                "ref": "http://d4.sina.com.cn/201211/22/465184_300-500-auto.swf",
                "content": ''
            }
        }
    },
	setContent: function(c) {
		switch (c.type) {
		case "swf":
			return '<object id="playerobj" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9" classid=clsid:d27cdb6e-ae6d-11cf-96b8-444553540000 width="' + c.width + '" height="' + c.height + '" type="application/x-shockwave-flash"><param name="movie" value="' + c.ref + '"><param name="wmode" value="transparent"><param name="quality" value="high"><param name="allowscriptaccess" value="always"><param name="scale" value="exactfit"><embed name="playerobj" width="' + c.width + '" height="' + c.height + '" src="' + c.ref + '"  quality="high" allowScriptAccess="always" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" wmode="transparent" scale="exactfit"></embed></object>';
			break;
		case "pic":
			return '<a href="' + c.click + '" target="_blank"><img src="' + c.ref + '" width=' + c.width + "px height=" + c.height + 'px" /></a>';
			break;
		case "flv":
			return this.playerize(c.width, c.height, c.ref, c.click, c.ref2);
			break;
		case "txt":
			var data = c.txtarr;
			var str = "";
			for (var i = 0; i < data.length; i++) {
				str = str + '<li><p><span class="SG_dot"></span><a href="' + data[i]["href"] + '" target="_blank">' + data[i]["content"] + '</a></p></li>';
			}
			str = '<ul class="onlylist cmtA_arti">' + str + '</ul>';
			return str;
			break;
		case "iframe":
			return '<iframe width="' + c.width + '" height="' + c.height + '" frameborder="0" scrolling="no" src="' + (c.ref) + '"></iframe>';
			break;
		}
	},
	playerize: function(width, height, ref, clickfun, ref2) {
		return '<iframe width="' + width + '" height="' + height + '" frameborder="0" scrolling="no" src="http://pfp.sina.com.cn/blog/blogplayer.html?flvurl=' + encodeURIComponent(ref) + '&linkurl=' + encodeURIComponent(clickfun) + '&width=' + width + '&height=' + height + '&pic=' + ref2 + '"></iframe>';
	}
};
(function() {
	BLOG_AD.leftsx.ads["0"].content = BLOG_AD.setContent(BLOG_AD.leftsx.ads["0"]);
	BLOG_AD.leftsx.ads["0"].type = "mix";
	BLOG_AD.leftsx.ads["1"].content = BLOG_AD.setContent(BLOG_AD.leftsx.ads["1"]);
	BLOG_AD.leftsx.ads["1"].type = "mix";
})();