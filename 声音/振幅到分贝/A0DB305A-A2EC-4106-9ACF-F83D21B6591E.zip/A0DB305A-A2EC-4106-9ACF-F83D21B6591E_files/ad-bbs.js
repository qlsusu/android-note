﻿var ad_type = 'ibm28';
var ad_sc = '<script type="text/javascript" '
    + 'src="http://ad.csdn.net/scripts/ad-' + ad_type + '.js"'
    + '></'
    + 'script>';
if(new Date()<new Date(2012,8,28)){
document.writeln(ad_sc);
}
