var phpadsbanner = '';

phpadsbanner += '<'+'a href=\'http://z.csdn.net/gmclick.php?bannerid=6792&amp;zoneid=448&amp;source=&amp;dest=http%3A%2F%2Fe.cn.miaozhen.com%2Fr.gif%3Fk%3D1002376%26p%3D3xw8v0%26o%3Dhttp%3A%2F%2Fad-apac.doubleclick.net%2Fclick%3Bh%3Dv2%7C3F81%7C0%7C0%7C%252a%7Ch%3B259610911%3B0-0%3B0%3B83765866%3B31-1%7C1%3B49192926%7C49188229%7C1%3B%3B%253fhttp%3A%2F%2Fwww.ibm.com%2Fsystems%2Fcn%2Fpromotion%2Fesg%2Fxseries%2Fnewgeneration%2Fbanner.shtml%3Fcsr%3Dapch_cfg3_20120711_1342011976135%26ck%3Dcsdn%26cmp%3D215ff%26ct%3D215ff08w%26cr%3Dcsdn%26cm%3Db%26csot%3D-%26ccy%3Dcn%26cpb%3D-%26cd%3D2012-07-10%26cot%3Da%26cpg%3Doff%26cn%3Des%3A_x3650_m4%26csz%3D728%2A90\' target=\'_blank\'>下载IBM Systemx3650M4白皮书<'+'/a>';

document.write(phpadsbanner);
