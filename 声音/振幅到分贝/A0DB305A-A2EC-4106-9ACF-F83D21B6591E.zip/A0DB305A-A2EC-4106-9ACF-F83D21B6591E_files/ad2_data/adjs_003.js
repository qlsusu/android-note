var phpadsbanner = '';

phpadsbanner += '<'+'a href=\'http://z.csdn.net/gmclick.php?bannerid=6864&amp;zoneid=384&amp;source=&amp;dest=http%3A%2F%2Fe.cn.miaozhen.com%2Fr.gif%3Fk%3D1002333%26p%3D3xyEE0%26o%3Dhttp%3A%2F%2Fwww-31.ibm.com%2Fibm%2Fcn%2Fcloud%2Fsolution%2Fbari%2Findex.shtml%3Fcsr%3Dapch_cyl3_20120801_1343793341976%26ck%3Dcsdn%26cmp%3D215tg%26ct%3D215tg23w%26cr%3Dcsdn%26cm%3Db%26csot%3D-%26ccy%3Dcn%26cpb%3D-%26cd%3D2012-07-31%26cot%3Da%26cpg%3Dtcny%26cn%3Duniversity_of_bari%26csz%3D760%2A90\' target=\'_blank\'>下载白皮书：云计算触发行业大变革<'+'/a>';

document.write(phpadsbanner);
