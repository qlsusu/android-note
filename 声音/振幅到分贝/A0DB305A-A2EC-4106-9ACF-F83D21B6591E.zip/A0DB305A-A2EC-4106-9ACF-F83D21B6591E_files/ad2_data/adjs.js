var phpadsbanner = '';

phpadsbanner += '<'+'a href=\'http://z.csdn.net/gmclick.php?bannerid=6795&amp;zoneid=447&amp;source=&amp;dest=http%3A%2F%2Fe.cn.miaozhen.com%2Fr.gif%3Fk%3D1002376%26p%3D3xw7p0%26o%3Dhttp%3A%2F%2Fad-apac.doubleclick.net%2Fclick%3Bh%3Dv2%7C3F81%7C0%7C0%7C%252a%7Cq%3B259610168%3B0-0%3B0%3B83764605%3B31-1%7C1%3B49192013%7C49187316%7C1%3B%3B%253fhttp%3A%2F%2Fwww.ibm.com%2Fsystems%2Fcn%2Fads%2F2012q1_bcfc.shtml%3Fcsr%3Dapch_cfg3_20120711_1342010369789%26ck%3Dcsdn%26cmp%3D215ff%26ct%3D215ff06w%26cr%3Dcsdn%26cm%3Db%26csot%3D-%26ccy%3Dcn%26cpb%3D-%26cd%3D2012-07-10%26cot%3Da%26cpg%3Doff%26cn%3Dintel_cloud_-blade_foundation_for_cloud%26csz%3D960%2A90\' target=\'_blank\'>免费下载 SKC易云解决方案<'+'/a>';

document.write(phpadsbanner);
