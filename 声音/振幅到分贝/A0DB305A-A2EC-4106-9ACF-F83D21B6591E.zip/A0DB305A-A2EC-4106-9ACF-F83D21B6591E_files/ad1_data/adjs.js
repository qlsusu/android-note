var phpadsbanner = '';

phpadsbanner += '<'+'a href=\'http://z.csdn.net/gmclick.php?bannerid=6850&amp;zoneid=383&amp;source=&amp;dest=http%3A%2F%2Fmdcc.csdn.net\' target=\'_blank\'><'+'img src=\'http://info-database.csdn.net/Upload/2012-09-20/mdcc-475-60-0920.gif\' width=\'475\' height=\'60\' alt=\'\' title=\'\' border=\'0\'><'+'/a><'+'div id="beacon_6850" style="position: absolute; left: 0px; top: 0px; visibility: hidden;"><'+'img src=\'http://z.csdn.net/gmlog.php?bannerid=6850&amp;clientid=2382&amp;zf=&amp;zoneid=383&amp;source=&amp;block=0&amp;capping=0&amp;cb=582b6d6e5ae6c3182082417b2ee65126\' width=\'0\' height=\'0\' alt=\'\' style=\'width: 0px; height: 0px;\'><'+'/div>';

document.write(phpadsbanner);
