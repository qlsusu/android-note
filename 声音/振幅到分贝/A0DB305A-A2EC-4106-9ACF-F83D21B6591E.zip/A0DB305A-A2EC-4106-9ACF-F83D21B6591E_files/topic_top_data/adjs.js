var phpadsbanner = '';

phpadsbanner += '<'+'a href=\'http://z.csdn.net/gmclick.php?bannerid=6902&amp;zoneid=429&amp;source=&amp;dest=http%3A%2F%2Fwww.sapteched.com%2Fchina%2F12%2Fcn%2Findex%2Fhome.asp\' target=\'_blank\'><'+'img src=\'http://info-database.csdn.net/Upload/2012-09-04/sap-210-60-0904.gif\' width=\'210\' height=\'60\' alt=\'\' title=\'\' border=\'0\'><'+'/a><'+'div id="beacon_6902" style="position: absolute; left: 0px; top: 0px; visibility: hidden;"><'+'img src=\'http://z.csdn.net/gmlog.php?bannerid=6902&amp;clientid=2427&amp;zf=&amp;zoneid=429&amp;source=&amp;block=0&amp;capping=0&amp;cb=b4bfdcce4294ba062aee61ecec54cf93\' width=\'0\' height=\'0\' alt=\'\' style=\'width: 0px; height: 0px;\'><'+'/div>';

document.write(phpadsbanner);
