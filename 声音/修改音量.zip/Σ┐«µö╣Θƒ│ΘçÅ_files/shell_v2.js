var bdShare=bdShare||{};bdShare.loadTime=+new Date;document.getElementById("bdshare_js").src="http://bdimg.share.baidu.com/static/js/bds_s_v2.js?cdnversion=20120828";
