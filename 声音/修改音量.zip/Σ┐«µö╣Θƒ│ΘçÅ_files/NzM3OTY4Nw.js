var _Cnf = {
	url: '/forum-26-1.html|/forum.php',
	isValid: true
};
