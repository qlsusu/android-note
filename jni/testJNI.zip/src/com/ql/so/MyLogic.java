package com.ql.so;

public class MyLogic {
	public native int add(int x, int y);
}
