package com.ql.testJNI;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

import com.ql.so.MyLogic;

public class Test extends Activity {
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		MyLogic logic = new MyLogic();
		String result = logic.add(23, 2) + "";

		((TextView) (findViewById(R.id.text))).setText("result is:" + result);
	}
	
	static {
		System.loadLibrary("MyLogic");
	}
}