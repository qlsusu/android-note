/** Automatically generated file. DO NOT MODIFY */
package me.kevingleason.pnwebrtc;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}