package com.ql.plugininstall;

import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import dalvik.system.DexClassLoader;

public class MainActivity extends AppCompatActivity {

    private String apkPath;
    private AssetManager mAssetManager;
    private Resources mResources;
    private Resources.Theme mTheme;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        loadClass();
        accessResource();
    }

    private void loadClass() {
        apkPath = Environment.getExternalStorageDirectory() + "/bill/pluginsource-debug.apk";
        final String clzName = "com.ql.pluginsource.SourceLogic";

//        PackageInfo packageInfo = getPackageManager().getPackageArchiveInfo(apkPath, PackageManager.GET_ACTIVITIES);
//        ActivityInfo[] activities = packageInfo.activities;

        DexClassLoader dexClassLoader = new DexClassLoader(apkPath, getDir("dex", Context.MODE_PRIVATE).getAbsolutePath(), null, ClassLoader.getSystemClassLoader());
        try {
            Class clz = dexClassLoader.loadClass(clzName);
            Object obj = clz.newInstance();
            Method method = clz.getDeclaredMethod("logic", new Class[]{});
            int value = (int) method.invoke(obj, new Object[]{});
            System.out.println("value is:" + value);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
    }

    private void accessResource() {
        initResources();
        loadResource("com.ql.pluginsource/string:hello");
    }

    private void initResources() {
        try {
            AssetManager assetManager = AssetManager.class.newInstance();
            Method addAssetPath = assetManager.getClass().getMethod("addAssetPath", String.class);
            addAssetPath.invoke(assetManager, apkPath);
            mAssetManager = assetManager;
        } catch (Exception e) {
            e.printStackTrace();
        }
        Resources superRes = getResources();
        mResources = new Resources(mAssetManager, superRes.getDisplayMetrics(),
                superRes.getConfiguration());
        mTheme = mResources.newTheme();
        mTheme.setTo(super.getTheme());
    }

    private void loadResource(String name) {
        int id = mResources.getIdentifier(name, null, null);
        System.out.println("resource:" + mResources.getString(id));
    }
}
