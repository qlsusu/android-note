package com.ql.dexmaker;

import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.android.dx.BinaryOp;
import com.android.dx.Code;
import com.android.dx.DexMaker;
import com.android.dx.FieldId;
import com.android.dx.Local;
import com.android.dx.MethodId;
import com.android.dx.TypeId;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import dalvik.system.DexClassLoader;
import dalvik.system.DexFile;

//import com.android.dx.stock.ProxyBuilder;

public class ProxyWayActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        makeProxy();
        initView();
    }

    private Class proxyClz;

    private void makeProxy() {
        final String apkPath = Environment.getExternalStorageDirectory() + "/bill/plugin.apk";

        DexClassLoader dexClassLoader = new DexClassLoader(
                apkPath,
                getDir("dex", Context.MODE_PRIVATE).getAbsolutePath(),
                null,
                ClassLoader.getSystemClassLoader());

        //加载class
        String clzName = "com.ql.dexmaker.PluginRoutineActivity";
        try {
            Class clz = dexClassLoader.loadClass(clzName);
            //使用PluginBuilder来生成PluginRoutineActivity的一个子类
            ProxyBuilder proxyBuilder = ProxyBuilder.forClass(clz);
            proxyBuilder.handler(new InvocationHandler() {
                @Override
                public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                    System.out.println("invoke this method:" + method);
                    //调用PluginRoutineActivity的父类方法
                    return ProxyBuilder.callSuper(proxy, method, args);
                }
            });
            proxyBuilder.parentClassLoader(dexClassLoader);
//            proxyBuilder.setProxyClzName("com.ql.dexmaker.StubActivity");

            proxyClz = proxyBuilder.buildProxyClass();
            System.out.println(proxyClz);

            //修改proxyclz的name，为什么：
            //在主app中，仅仅定义了一个钩子activity（主app不用管有多少类plugin activity）
            //proxy activity声称是该钩子，但是内部实现却是每个plugin activity
            Field name = proxyClz.getClass().getDeclaredField("name");
            name.setAccessible(true);
            name.set(proxyClz, "com.ql.dexmaker.StubActivity");

            try {
                AssetManager assetManager = AssetManager.class.newInstance();
                Method addAssetPath = assetManager.getClass().getMethod("addAssetPath", String.class);
                addAssetPath.invoke(assetManager, apkPath);

                Resources superRes = getResources();
                Resources resources = new Resources(assetManager, superRes.getDisplayMetrics(),
                        superRes.getConfiguration());

                Field resourceField = proxyClz.getSuperclass().getDeclaredField("resources");
                resourceField.setAccessible(true);
                resourceField.set(null, resources);

                // TODO: 17/9/3 将proxy activity对应的dex也放入到classloader.pathlist.dexelements中，则找到了该钩子activity 
                patchClassLoader(getClassLoader(), new File(apkPath), getDir("dex123", Context.MODE_PRIVATE));

//            Field resourceField = getClass().getSuperclass().getDeclaredField("mResources");
//            resourceField.setAccessible(true);
//            System.out.println(resourceField);
//            resourceField.set(this, resources);
            } catch (Exception e) {
                System.out.println("errot happen:" + e);
                e.printStackTrace();
            }

            Object proxy = proxyBuilder.build();
            Method method = proxyClz.getDeclaredMethod("method1");
            method.invoke(proxy);

//             myLogic= (MyLogic) proxyBuilder.build();
//            System.out.println(myLogic.getClass().getSuperclass());
//            myLogic.method1();
//            myLogic.method2();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        }
    }

    public static void patchClassLoader(ClassLoader cl, File apkFile, File optDexFile)
            throws IllegalAccessException, NoSuchMethodException, IOException, InvocationTargetException, InstantiationException, NoSuchFieldException {
        // 获取 BaseDexClassLoader : pathList
        Field pathListField = DexClassLoader.class.getSuperclass().getDeclaredField("pathList");
        pathListField.setAccessible(true);
        Object pathListObj = pathListField.get(cl);

        // 获取 PathList: Element[] dexElements
        Field dexElementArray = pathListObj.getClass().getDeclaredField("dexElements");
        dexElementArray.setAccessible(true);
        Object[] dexElements = (Object[]) dexElementArray.get(pathListObj);

        // Element 类型
        Class<?> elementClass = dexElements.getClass().getComponentType();

        // 创建一个数组, 用来替换原始的数组
        Object[] newElements = (Object[]) Array.newInstance(elementClass, dexElements.length + 1);

        // 构造插件Element(File file, boolean isDirectory, File zip, DexFile dexFile) 这个构造函数
        Constructor<?> constructor = elementClass.getConstructor(File.class, boolean.class, File.class, DexFile.class);
        Object o = constructor.newInstance(apkFile, false, apkFile, DexFile.loadDex(apkFile.getCanonicalPath(), optDexFile.getAbsolutePath(), 0));

        Object[] toAddElementArray = new Object[]{o};
        // 把原始的elements复制进去
        System.arraycopy(dexElements, 0, newElements, 0, dexElements.length);
        // 插件的那个element复制进去
        System.arraycopy(toAddElementArray, 0, newElements, dexElements.length, toAddElementArray.length);

        // 替换
        dexElementArray.set(pathListObj, newElements);

    }

    private void initView() {
        findViewById(R.id.go_to_plugin).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), proxyClz);
                startActivity(intent);
            }
        });
    }

    public void makeDex() throws Exception {
        DexMaker dexMaker = new DexMaker();

        // Generate a HelloWorld class.
        TypeId<?> helloWorld = TypeId.get("LHelloWorld;");
        dexMaker.declare(helloWorld, "HelloWorld.generated", Modifier.PUBLIC, TypeId.OBJECT);
        generateHelloMethod(dexMaker, helloWorld);

        // Create the dex file and load it.
        File outputDir = getDir("dex", Context.MODE_PRIVATE);
        ClassLoader loader = dexMaker.generateAndLoad(getClassLoader(),
                outputDir);
        Class<?> helloWorldClass = loader.loadClass("HelloWorld");

        // Execute our newly-generated code in-process.
        helloWorldClass.getMethod("hello").invoke(null);
    }

    /**
     * Generates Dalvik bytecode equivalent to the following method.
     * public static void hello() {
     * int a = 0xabcd;
     * int b = 0xaaaa;
     * int c = a - b;
     * String s = Integer.toHexString(c);
     * System.out.println(s);
     * return;
     * }
     */
    private static void generateHelloMethod(DexMaker dexMaker, TypeId<?> declaringType) {
        // Lookup some types we'll need along the way.
        TypeId<System> systemType = TypeId.get(System.class);
        TypeId<PrintStream> printStreamType = TypeId.get(PrintStream.class);

        // Identify the 'hello()' method on declaringType.
        MethodId hello = declaringType.getMethod(TypeId.VOID, "hello");

        // Declare that method on the dexMaker. Use the returned Code instance
        // as a builder that we can append instructions to.
        Code code = dexMaker.declare(hello, Modifier.STATIC | Modifier.PUBLIC);

        // Declare all the locals we'll need up front. The API requires this.
        Local<Integer> a = code.newLocal(TypeId.INT);
        Local<Integer> b = code.newLocal(TypeId.INT);
        Local<Integer> c = code.newLocal(TypeId.INT);
        Local<String> s = code.newLocal(TypeId.STRING);
        Local<PrintStream> localSystemOut = code.newLocal(printStreamType);

        // int a = 0xabcd;
        code.loadConstant(a, 0xabcd);

        // int b = 0xaaaa;
        code.loadConstant(b, 0xaaaa);

        // int c = a - b;
        code.op(BinaryOp.SUBTRACT, c, a, b);

        // String s = Integer.toHexString(c);
        MethodId<Integer, String> toHexString
                = TypeId.get(Integer.class).getMethod(TypeId.STRING, "toHexString", TypeId.INT);
        code.invokeStatic(toHexString, s, c);

        // System.out.println(s);
        FieldId<System, PrintStream> systemOutField = systemType.getField(printStreamType, "out");
        code.sget(systemOutField, localSystemOut);
        MethodId<PrintStream, Void> printlnMethod = printStreamType.getMethod(
                TypeId.VOID, "println", TypeId.STRING);
        code.invokeVirtual(printlnMethod, null, localSystemOut, s);

        // return;
        code.returnVoid();
    }
}
