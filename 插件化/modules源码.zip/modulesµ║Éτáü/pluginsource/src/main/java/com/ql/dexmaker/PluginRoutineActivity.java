package com.ql.dexmaker;

import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.ContextThemeWrapper;

import com.ql.pluginsource.R;

import java.lang.reflect.Field;

public class PluginRoutineActivity extends FragmentActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        System.out.println("oncreate is here");

        // TODO: 17/9/3 主题设置无效
        setTheme(R.style.AppThemeHolo);

        Field resourceField;
        try {
            resourceField = ContextThemeWrapper.class.getDeclaredField("mResources");
            resourceField.setAccessible(true);
            System.out.println(resourceField);
            resourceField.set(this, resources);
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }

        Bundle bundle = getIntent().getExtras();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.plugin1);

        // TODO: 17/9/3 跳入到其他activity无效，因为：未在 主app.manifest.xml中声明
//        startActivity(new Intent(getApplicationContext(), PluginActivity1.class));
    }

    private static Resources resources;
}
